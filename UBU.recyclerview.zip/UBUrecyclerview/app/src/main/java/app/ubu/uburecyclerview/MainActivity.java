package app.ubu.uburecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

import app.ubu.uburecyclerview.model.Food;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // เก็บ Food 3 อย่างไว้ใน ArrayList<Food> ชื่อว่า foods
        //
        List<Food> foods = new ArrayList<Food>();
        Food food = new Food();
        food.setFood_name("ผัดไทย");
        food.setFood_image("https://c0.wallpaperflare.com/preview/718/943/615/pad-thai-thai-food-thailand-asian-food.jpg");
        food.setFood_price(45);
        foods.add(food);

        Food food2 = new Food();
        food2.setFood_name("กระเพราหมูกรอบ");
        food2.setFood_image("https://img.wongnai.com/p/1920x0/2021/01/17/c95146b336274b0283b92b6943d289d8.jpg");
        food2.setFood_price(50);
        foods.add(food2);

        Food food3 = new Food();
        food3.setFood_name("พะแนงไก่");
        food3.setFood_image("https://cms.dmpcdn.com/food/2021/10/12/7e8c8750-2b36-11ec-bfd9-97090d4e24ba_original.jpg");
        food3.setFood_price(40);
        foods.add(food3);


        // ส่ง foods ไปให้ MyAdapter
        //
        mAdapter = new MyAdapter(foods, this);
        recyclerView.setAdapter(mAdapter);
    }
}